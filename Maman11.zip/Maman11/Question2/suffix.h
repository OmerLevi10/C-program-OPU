#ifndef SUFFIX_H
#define SUFFIX_H

int suffix(char c, char str[]);

#endif /* SUFFIX_H */
