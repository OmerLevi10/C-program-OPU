#ifndef MY_ADD_H
#define MY_ADD_H

unsigned int my_add(unsigned int a, unsigned int b);

#endif /* MY_ADD_H */
